package com.example.student.university_career_platform.controller;

import com.example.student.university_career_platform.service.CounselingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.io.IOException;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

@RestController
@RequestMapping("/api/chat")
@CrossOrigin // 允许跨域
public class ChatController {

    @Autowired
    private CounselingService counselingService;

    /**
     * 注意这里 produces 必须是 TEXT_EVENT_STREAM_VALUE，这是流式输出的灵魂
     */
    @PostMapping(value = "/qwen/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public SseEmitter streamChat(@RequestBody Map<String, String> request) {
        String userMessage = request.get("message");

        // 1. 创建 SseEmitter，设置超时时间为 60 秒（或者 0 代表永不超时）
        SseEmitter emitter = new SseEmitter(60000L);

        if (userMessage == null || userMessage.trim().isEmpty()) {
            emitter.completeWithError(new IllegalArgumentException("消息不能为空"));
            return emitter;
        }

        // 2. 必须在另一个线程中执行，不能阻塞主线程，否则前端拿不到实时的数据流
        CompletableFuture.runAsync(() -> {
            try {
                // 调用你现有的 Service 拿到大模型完整回复（这里会稍微等一下）
                String fullReply = counselingService.chatWithStudent(userMessage);

                // 3. 核心戏法：切片发送，模拟打字机效果！
                // 每次发 2 个字符，间隔 30 毫秒，前端看起来就会非常丝滑
                for (int i = 0; i < fullReply.length(); i += 2) {
                    int MathEnd = Math.min(i + 2, fullReply.length());
                    String chunk = fullReply.substring(i, MathEnd);

                    // 把这一小块推给前端
                    emitter.send(chunk);

                    // 稍微停顿一下
                    Thread.sleep(30);
                }

                // 4. 数据全部发送完毕，告诉前端可以关闭连接了
                emitter.complete();

            } catch (Exception e) {
                // 如果中间出了岔子，通知前端报错
                emitter.completeWithError(e);
            }
        });

        return emitter;
    }

    /**
     * 从请求中提取用户消息
     */
    private String extractUserMessage(Map<String, Object> request) {
        if (request.containsKey("message")) {
            Object msg = request.get("message");
            return msg != null ? msg.toString() : null;
        }

        if (request.containsKey("messages")) {
            Object msgsObj = request.get("messages");
            if (msgsObj instanceof java.util.List) {
                java.util.List<?> msgs = (java.util.List<?>) msgsObj;
                if (!msgs.isEmpty()) {
                    Object lastMsg = msgs.get(msgs.size() - 1);
                    if (lastMsg instanceof Map) {
                        Object content = ((Map<?, ?>) lastMsg).get("content");
                        return content != null ? content.toString() : null;
                    }
                    return lastMsg != null ? lastMsg.toString() : null;
                }
            }
        }

        return null;
    }
}