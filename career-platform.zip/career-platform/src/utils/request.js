// src/utils/request.js
import axios from 'axios'
import router from '../router' // 引入路由以便跳转

// 1. 创建 axios 实例
const request = axios.create({
  baseURL: 'http://localhost:8080', // 替换为你 Spring Boot 后端的真实地址和端口
  timeout: 5000 // 请求超时时间
})

// 2. 请求拦截器：发请求前，自动带上 Token
request.interceptors.request.use(
  config => {
    // 从 localStorage 获取 token
    const token = localStorage.getItem('token')
    if (token) {
      // 如果有 token，就放到请求头里（Bearer 是 JWT 的标准格式）
      config.headers['Authorization'] = `Bearer ${token}`
    }
    return config
  },
  error => {
    return Promise.reject(error)
  }
)

// 3. 响应拦截器：处理后端的返回结果
request.interceptors.response.use(
  response => {
    // 如果 HTTP 状态码是 200，说明请求成功，直接返回数据
    return response.data
  },
  error => {
    // 如果后端返回 401 (Unauthorized)，说明 Token 过期或没登录
    if (error.response && error.response.status === 401) {
      alert('登录已过期，请重新登录')
      localStorage.removeItem('token')      // 清除失效的 token
      localStorage.removeItem('userName')   // 清除用户信息
      router.push('/login')                 // 强制跳回登录页
    } else {
      // 其他错误（比如密码错误 400 等），弹出后端给的提示
      const msg = error.response?.data || '网络请求失败'
      alert(msg)
    }
    return Promise.reject(error)
  }
)

export default request