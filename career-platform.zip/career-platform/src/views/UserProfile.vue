<template>
  <div class="user-profile-container">
    <div class="profile-layout">
      
      <aside class="sidebar">
        <div class="sidebar-title">个人中心</div>
        <ul class="menu-list">
          <li 
            v-for="item in menuItems" 
            :key="item.id"
            :class="['menu-item', { active: currentTab === item.id }]"
            @click="currentTab = item.id"
          >
            <span class="icon">{{ item.icon }}</span>
            {{ item.label }}
          </li>
        </ul>
      </aside>

      <main class="content-area">
        
        <div v-if="currentTab === 'home'" class="tab-panel">
          <h2 class="panel-title">主页概览</h2>
          <div class="user-card">
            <img :src="userInfo.avatar" alt="Avatar" class="large-avatar" />
            <div class="user-brief">
              <h3>{{ userInfo.username }} <span class="level-tag">LV 4</span></h3>
              <p class="user-id">UID: {{ userInfo.uid }}</p>
              <p class="user-bio">{{ userInfo.bio || '这个人很懒，什么都没写~' }}</p>
            </div>
          </div>
          <div class="stats-row">
            <div class="stat-box"><strong>12</strong><span>关注</span></div>
            <div class="stat-box"><strong>145</strong><span>粉丝</span></div>
            <div class="stat-box"><strong>50</strong><span>获赞</span></div>
          </div>
        </div>

        <div v-if="currentTab === 'info'" class="tab-panel">
          <h2 class="panel-title">我的信息</h2>
          
          <div class="form-group avatar-group">
            <label>当前头像：</label>
            <div class="avatar-wrapper">
              <img :src="userInfo.avatar" alt="Avatar" class="current-avatar" />
              <button class="btn btn-outline">上传新头像</button>
            </div>
          </div>

          <div class="form-group">
            <label>昵称：</label>
            <input type="text" v-model="userInfo.username" class="form-input" placeholder="请输入昵称" />
          </div>

          <div class="form-group">
            <label>个性签名：</label>
            <textarea v-model="userInfo.bio" class="form-textarea" placeholder="介绍一下自己吧"></textarea>
          </div>

          <button class="btn btn-primary" @click="saveInfo">保存修改</button>
        </div>

        <div v-if="currentTab === 'security'" class="tab-panel">
          <h2 class="panel-title">账号安全</h2>
          
          <div class="security-list">
            <div class="security-item">
              <div class="sec-info">
                <span class="sec-icon">📱</span>
                <div class="sec-text">
                  <h4>绑定手机</h4>
                  <p>已绑定：{{ formatPhone(userInfo.phone) }}</p>
                </div>
              </div>
              <button class="btn btn-text">更改手机</button>
            </div>

            <div class="security-item">
              <div class="sec-info">
                <span class="sec-icon">📧</span>
                <div class="sec-text">
                  <h4>绑定邮箱</h4>
                  <p>未绑定邮箱，绑定后可用于登录和找回密码</p>
                </div>
              </div>
              <button class="btn btn-outline">去绑定</button>
            </div>

            <div class="security-item">
              <div class="sec-info">
                <span class="sec-icon">🔒</span>
                <div class="sec-text">
                  <h4>登录密码</h4>
                  <p>建议定期更改密码以保护账号安全</p>
                </div>
              </div>
              <button class="btn btn-outline">修改密码</button>
            </div>
          </div>
        </div>

        <div v-if="currentTab === 'history'" class="tab-panel">
          <h2 class="panel-title">观看记录</h2>
          <div class="empty-state">
            <p>暂无观看记录</p>
          </div>
        </div>

        <div v-if="currentTab === 'notifications'" class="tab-panel">
          <h2 class="panel-title">通知设置</h2>
          <div class="toggle-list">
            <div class="toggle-item">
              <span>系统通知 (系统升级、维护等)</span>
              <input type="checkbox" checked class="toggle-switch" />
            </div>
            <div class="toggle-item">
              <span>互动通知 (点赞、评论、回复)</span>
              <input type="checkbox" checked class="toggle-switch" />
            </div>
            <div class="toggle-item">
              <span>私信接收设置</span>
              <select class="form-select">
                <option>接收所有人</option>
                <option>仅接收关注的人</option>
                <option>不接收</option>
              </select>
            </div>
          </div>
        </div>

      </main>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'

// 侧边栏菜单配置
const menuItems = [
  { id: 'home', label: '首 页', icon: '🏠' },
  { id: 'info', label: '我的信息', icon: '📝' },
  { id: 'security', label: '账号安全', icon: '🛡️' },
  { id: 'history', label: '观看记录', icon: '🕒' },
  { id: 'notifications', label: '通知设置', icon: '🔔' }
]

// 当前选中的 Tab，默认主页
const currentTab = ref('home')

// 模拟用户信息数据
const userInfo = ref({
  uid: '17613689610',
  username: '人如故',
  avatar: 'https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png', // 替换为真实默认头像
  bio: '',
  phone: '13812345678'
})

// 脱敏手机号显示
const formatPhone = (phone) => {
  if (!phone) return ''
  return phone.replace(/(\d{3})\d{4}(\d{4})/, '$1****$2')
}

// 模拟保存信息
const saveInfo = () => {
  alert('信息保存成功！')
}
</script>

<style scoped>
/* 整体页面背景 */
.user-profile-container {
  min-height: calc(100vh - 60px); /* 假设顶部导航栏高度为60px */
  background-color: #f4f5f7;
  padding: 20px 0;
  display: flex;
  justify-content: center;
}

/* 左右分栏布局容器 */
.profile-layout {
  width: 1000px;
  max-width: 95%;
  display: flex;
  gap: 16px;
  align-items: flex-start;
}

/* 左侧边栏样式 */
.sidebar {
  width: 200px;
  background: #fff;
  border-radius: 6px;
  padding: 16px 0;
  box-shadow: 0 2px 4px rgba(0,0,0,0.04);
}

.sidebar-title {
  font-size: 16px;
  font-weight: bold;
  color: #222;
  padding: 0 20px 16px;
  border-bottom: 1px solid #e5e9ef;
  margin-bottom: 8px;
}

.menu-list {
  list-style: none;
  padding: 0;
  margin: 0;
}

.menu-item {
  height: 48px;
  line-height: 48px;
  padding: 0 24px;
  font-size: 14px;
  color: #666;
  cursor: pointer;
  transition: all 0.3s;
  display: flex;
  align-items: center;
  gap: 10px;
}

.menu-item:hover {
  background-color: #f4f5f7;
  color: #00a1d6; /* 哔哩哔哩主题蓝 */
}

.menu-item.active {
  background-color: #00a1d6;
  color: #fff;
}

/* 右侧内容区样式 */
.content-area {
  flex: 1;
  background: #fff;
  border-radius: 6px;
  min-height: 600px;
  padding: 30px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.04);
}

.panel-title {
  font-size: 18px;
  color: #222;
  margin-top: 0;
  margin-bottom: 24px;
  padding-bottom: 16px;
  border-bottom: 1px solid #e5e9ef;
}

/* 个人名片样式 */
.user-card {
  display: flex;
  align-items: center;
  gap: 20px;
  margin-bottom: 30px;
}

.large-avatar {
  width: 80px;
  height: 80px;
  border-radius: 50%;
  border: 2px solid #fff;
  box-shadow: 0 0 10px rgba(0,0,0,0.1);
}

.user-brief h3 {
  margin: 0 0 8px 0;
  font-size: 20px;
  display: flex;
  align-items: center;
  gap: 8px;
}

.level-tag {
  background: #f3a034;
  color: #fff;
  font-size: 12px;
  padding: 2px 6px;
  border-radius: 4px;
  font-weight: normal;
}

.user-id, .user-bio {
  margin: 4px 0;
  font-size: 13px;
  color: #666;
}

.stats-row {
  display: flex;
  gap: 40px;
  padding-top: 20px;
  border-top: 1px dashed #e5e9ef;
}

.stat-box {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.stat-box strong {
  font-size: 20px;
  color: #222;
}

.stat-box span {
  font-size: 12px;
  color: #99a2aa;
  margin-top: 4px;
}

/* 表单样式 */
.form-group {
  margin-bottom: 24px;
}

.form-group label {
  display: block;
  font-size: 14px;
  color: #333;
  margin-bottom: 8px;
}

.form-input, .form-textarea, .form-select {
  width: 100%;
  max-width: 400px;
  padding: 10px 12px;
  border: 1px solid #ccd0d7;
  border-radius: 4px;
  font-size: 14px;
  transition: border-color 0.2s;
}

.form-input:focus, .form-textarea:focus, .form-select:focus {
  outline: none;
  border-color: #00a1d6;
}

.form-textarea {
  height: 100px;
  resize: vertical;
}

.avatar-wrapper {
  display: flex;
  align-items: center;
  gap: 16px;
}

.current-avatar {
  width: 64px;
  height: 64px;
  border-radius: 50%;
}

/* 按钮样式 */
.btn {
  padding: 8px 20px;
  border-radius: 4px;
  font-size: 14px;
  cursor: pointer;
  border: none;
  transition: all 0.2s;
}

.btn-primary {
  background: #00a1d6;
  color: #fff;
}

.btn-primary:hover {
  background: #00b5e5;
}

.btn-outline {
  background: transparent;
  border: 1px solid #ccd0d7;
  color: #555;
}

.btn-outline:hover {
  border-color: #00a1d6;
  color: #00a1d6;
}

.btn-text {
  background: transparent;
  color: #00a1d6;
  padding: 0;
}

.btn-text:hover {
  color: #00b5e5;
}

/* 安全列表样式 */
.security-list {
  display: flex;
  flex-direction: column;
}

.security-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px 0;
  border-bottom: 1px solid #e5e9ef;
}

.sec-info {
  display: flex;
  align-items: center;
  gap: 16px;
}

.sec-icon {
  font-size: 24px;
}

.sec-text h4 {
  margin: 0 0 4px 0;
  font-size: 16px;
  color: #222;
}

.sec-text p {
  margin: 0;
  font-size: 13px;
  color: #99a2aa;
}

/* 通知设置开关 */
.toggle-list {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.toggle-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  max-width: 400px;
  font-size: 14px;
  color: #333;
}

/* 空状态 */
.empty-state {
  text-align: center;
  padding: 60px 0;
  color: #99a2aa;
  font-size: 14px;
}
</style>