<template>
  <div class="setup-container">
    <div class="glass-card">
      <h2 class="title">完善个人信息</h2>
      <p class="subtitle">只需最后一步，开启你的规划之旅</p>

      <form @submit.prevent="handleComplete">
        <div class="avatar-upload-box">
          <label for="avatar-input" class="avatar-preview">
            <img v-if="avatarUrl" :src="avatarUrl" alt="头像预览" />
            <div v-else class="upload-placeholder">
              <i>📷</i>
              <span>上传头像</span>
            </div>
          </label>
          <input id="avatar-input" type="file" accept="image/*" @change="onFileChange" hidden />
        </div>

        <div class="input-box">
          <input type="text" placeholder="设置一个好听的用户名" required v-model="form.username" />
        </div>

        <div class="form-row">
          <div class="input-box half-width">
            <input type="number" placeholder="年龄" min="1" max="120" required v-model="form.age" />
          </div>
          <div class="gender-group half-width">
            <label :class="{ active: form.gender === '男' }">
              <input type="radio" value="男" v-model="form.gender" hidden /> 男
            </label>
            <label :class="{ active: form.gender === '女' }">
              <input type="radio" value="女" v-model="form.gender" hidden /> 女
            </label>
          </div>
        </div>

        <button type="submit" class="submit-btn">完 成 并 登 录</button>
        
        <div class="action-links">
          <span class="skip-link" @click="skipSetup">先跳过，直接登录 ></span>
        </div>
      </form>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'

const router = useRouter()
const route = useRoute()

// 从注册页面接收角色
const role = ref('student')
onMounted(() => {
  if (route.query.role) {
    role.value = route.query.role
  }
})

const form = ref({
  username: '',
  age: '',
  gender: '男'
})

const avatarUrl = ref('')
const onFileChange = (e) => {
  const file = e.target.files[0]
  if (file) {
    avatarUrl.value = URL.createObjectURL(file)
  }
}

// 提交表单（无弹窗，静默登录）
const handleComplete = () => {
  localStorage.setItem('userRole', role.value)
  if (form.value.username) {
    localStorage.setItem('userName', form.value.username)
  }
  router.push('/dashboard')
}

// 跳过（无弹窗，静默登录）
const skipSetup = () => {
  localStorage.setItem('userRole', role.value)
  router.push('/dashboard')
}
</script>

<style scoped>
.setup-container { 
  height: 100vh; width: 100vw; 
  background: url('https://images.unsplash.com/photo-1519389950473-47ba0277781c?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80') center/cover no-repeat;
  display: flex; align-items: center; justify-content: center;
}
.glass-card {
  width: 420px; padding: 40px;
  background: rgba(255, 255, 255, 0.9);
  backdrop-filter: blur(10px);
  border-radius: 16px;
  box-shadow: 0 15px 35px rgba(0,0,0,0.2);
}
.title { text-align: center; margin-bottom: 5px; color: #333; }
.subtitle { text-align: center; color: #888; font-size: 14px; margin-bottom: 30px; }

/* 头像上传样式 */
.avatar-upload-box { display: flex; justify-content: center; margin-bottom: 25px; }
.avatar-preview {
  width: 80px; height: 80px; border-radius: 50%; border: 2px dashed #ccc;
  display: flex; align-items: center; justify-content: center; cursor: pointer;
  overflow: hidden; transition: border-color 0.3s; background: #f8fafc;
}
.avatar-preview:hover { border-color: #4a90e2; }
.avatar-preview img { width: 100%; height: 100%; object-fit: cover; }
.upload-placeholder { display: flex; flex-direction: column; align-items: center; color: #999; }
.upload-placeholder i { font-size: 24px; font-style: normal; margin-bottom: 2px; }
.upload-placeholder span { font-size: 12px; }

/* 表单输入框样式 */
.input-box { margin-bottom: 20px; }
.input-box input { width: 100%; padding: 12px 15px; border: 1px solid #ccc; border-radius: 8px; box-sizing: border-box; outline: none; transition: 0.3s; }
.input-box input:focus { border-color: #4a90e2; }

/* 并排的表单行（年龄和性别） */
.form-row { display: flex; gap: 15px; margin-bottom: 20px; }
.half-width { flex: 1; margin-bottom: 0; }
.gender-group { display: flex; gap: 10px; }
.gender-group label {
  flex: 1; display: flex; align-items: center; justify-content: center;
  border: 1px solid #ccc; border-radius: 8px; cursor: pointer; color: #666; transition: 0.3s;
}
.gender-group label.active { background: #e6f0fa; border-color: #4a90e2; color: #4a90e2; font-weight: bold; }

/* 按钮与链接 */
.submit-btn { width: 100%; padding: 12px; background: #4a90e2; color: white; border: none; border-radius: 8px; font-size: 16px; cursor: pointer; transition: 0.3s; }
.submit-btn:hover { background: #357abd; box-shadow: 0 4px 12px rgba(74, 144, 226, 0.4); }
.action-links { text-align: center; margin-top: 15px; }
.skip-link { color: #999; font-size: 14px; cursor: pointer; transition: 0.2s; }
.skip-link:hover { color: #4a90e2; }
</style>